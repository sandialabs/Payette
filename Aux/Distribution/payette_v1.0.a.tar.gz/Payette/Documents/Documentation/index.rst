.. Payette documentation master file, created by
   sphinx-quickstart on Fri Mar 23 22:53:54 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Payette Material Model Driver - Official Documentation
======================================================

.. toctree::
   :maxdepth: 2

   Files/introduction
   Files/obtaining
   Files/layout
   Files/building
   Files/running_payette
   Files/input_file_formatting
   Files/test_payette
   Files/installing_materials
   Files/optimization
   Files/permutation
   Files/materials


Indices and tables
==================

* :ref:`genindex`

* :ref:`search`

