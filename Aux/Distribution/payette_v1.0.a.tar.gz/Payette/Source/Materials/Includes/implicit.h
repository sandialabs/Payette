C  Ensure all floating point variables are double precision
C
       IMPLICIT DOUBLE PRECISION(A-H,O-Z)
