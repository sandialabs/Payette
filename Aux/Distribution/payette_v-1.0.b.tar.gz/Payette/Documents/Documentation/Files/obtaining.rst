
.. highlight:: rst

###################
Obtaining *Payette*
###################

*Payette* is an open source project licensed under the MIT license. A copy of
the source code may be obtained by contacting `Tim Fuller <tjfulle@sandia.gov>`_.

For students in the `School of Engineering <http://www.coe.utah.edu>`_ at the
University of Utah, a copy of *Payette* may by obtained by::

  git clone cade_lab_user_name@lenny.eng.utah.edu:/csm/local/git/Payette.git Payette
